package packageOne;

public class Person {
	
	//specify the field age and declare it public
	public int age = 12;
}
